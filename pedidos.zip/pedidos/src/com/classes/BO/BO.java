package com.classes.BO;

import Transferencia.*;

public class BO {
	public Transferencia permanencia = new JSON();
}
