package com.classes.DTO;

public abstract class Id {
	private int id = 0;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

}
